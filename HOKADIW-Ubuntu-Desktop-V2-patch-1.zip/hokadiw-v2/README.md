# HOKADIW Ubuntu Desktop V2

Ubuntu 24.04 Codespaces desktop/development environment.

## Included
- XFCE + noVNC browser desktop
- Docker Engine / Buildx / Compose v2
- Node.js 22
- Python 3.12
- Git + Git LFS + GitHub CLI
- Android ADB / Fastboot
- C/C++ build toolchain, clang, cmake
- Thai fonts + th_TH.UTF-8
- Common ports: 6080, 8080, 3000, 5173, 8000

## Desktop
```bash
bash .devcontainer/start-desktop.sh status
bash .devcontainer/start-desktop.sh restart
bash .devcontainer/start-desktop.sh stop
cat ~/.config/hokadiw-desktop/password.txt
```
Open forwarded port 6080 and keep it Private.

## System status
```bash
hokadiw-status
```

## Android
```bash
adb version
adb devices
fastboot --version
```
Note: Codespaces normally cannot directly access a USB-connected Android device on your local phone/PC. Use ADB-over-network only on devices/networks you control.

## Docker
```bash
docker version
docker compose version
docker compose up -d
```

## Rebuild
After replacing `.devcontainer`, use **Codespaces: Rebuild Container** so postCreateCommand installs the V2 toolset.
