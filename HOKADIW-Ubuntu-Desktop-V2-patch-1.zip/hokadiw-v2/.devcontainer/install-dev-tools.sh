#!/usr/bin/env bash
set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive

sudo apt-get update
sudo apt-get install -y --no-install-recommends \
  adb fastboot android-sdk-platform-tools-common \
  build-essential clang cmake make pkg-config \
  git git-lfs jq unzip zip rsync tree nano vim \
  htop iproute2 iputils-ping dnsutils net-tools \
  openssh-client shellcheck ripgrep fd-find \
  python3-venv python3-pip pipx

sudo apt-get clean
sudo rm -rf /var/lib/apt/lists/*

git lfs install --skip-repo || true
python3 -m pip --version >/dev/null 2>&1 || true

mkdir -p "$HOME/.local/bin"
cat > "$HOME/.local/bin/hokadiw-status" <<'STATUS'
#!/usr/bin/env bash
set -u
printf 'HOKADIW Ubuntu Desktop V2\n'
printf '%s\n' '-------------------------'
printf 'OS:      '; . /etc/os-release; echo "$PRETTY_NAME"
printf 'Kernel:  '; uname -r
printf 'Node:    '; node --version 2>/dev/null || echo 'not installed'
printf 'npm:     '; npm --version 2>/dev/null || echo 'not installed'
printf 'Python:  '; python3 --version 2>/dev/null || echo 'not installed'
printf 'Git:     '; git --version 2>/dev/null || echo 'not installed'
printf 'Docker:  '; docker --version 2>/dev/null || echo 'not ready'
printf 'Compose: '; docker compose version 2>/dev/null || echo 'not ready'
printf 'ADB:     '; adb version 2>/dev/null | head -n1 || echo 'not installed'
printf '\nDesktop:\n'
bash "$PWD/.devcontainer/start-desktop.sh" status 2>/dev/null || echo 'desktop status unavailable'
STATUS
chmod +x "$HOME/.local/bin/hokadiw-status"

grep -q 'HOME/.local/bin' "$HOME/.bashrc" || echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
echo "[HOKADIW] Developer tools installed."
